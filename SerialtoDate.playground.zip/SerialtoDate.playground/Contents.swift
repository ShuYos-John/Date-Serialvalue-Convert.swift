import UIKit

//737424 is the serial value of 2020/1/0 as 0
var DateSerialvalue:Double = 737425.5
var YearInt = 0
var MonthInt = 0
var DayInt = 0

var year = String()
var month = String()
var day = String()

/*
var decimal:Double = Double()
var decimalintoInt:Int = Int()
var Hour:String = String()
var Minit:String = String()
*/

func SerialtoDate (){
    
    let (fourhundredQuotient,fourhundredReminder) = Int(DateSerialvalue).quotientAndRemainder(dividingBy: 146097)
    //146097 = 365 * 400 + 1 * (100 + -4 + 1)
    let (hundredQuotient,hundredReminder) = (fourhundredReminder).quotientAndRemainder(dividingBy: 36524)
    //36524 = 365 * 100 + 1 * (25 + -1)
    let (fourQuotient,fourReminder) = (hundredReminder).quotientAndRemainder(dividingBy: 1461)
    //1461 = 365 * 4 + 1
    let (oneQuotient,oneReminder) = (fourReminder).quotientAndRemainder(dividingBy: 365)
    
    if oneReminder == 0{
        YearInt = 400 * fourhundredQuotient + 100 * hundredQuotient + 4 * fourQuotient + oneQuotient
    }
    if oneReminder != 0{
        YearInt = 400 * fourhundredQuotient + 100 * hundredQuotient + 4 * fourQuotient + oneQuotient + 1
    }
    
    let Jan:Int = 31
    var Feb:Int = 28
    if  145731 <= fourhundredReminder, fourhundredReminder <= 146097, 36158 <= hundredReminder, hundredReminder <= 36524, 1095 <= fourReminder, fourReminder <= 1461{
        Feb = 29
    }
    else if  36158 <= hundredReminder, hundredReminder <= 36524, 1095 <= fourReminder, fourReminder <= 1461{
        Feb = 28
    }
    else if  1095 <= fourReminder, fourReminder <= 1461{
        Feb = 29
    }
    let Mar:Int = 31
    let Apr:Int = 30
    let May:Int = 31
    let Jun:Int = 30
    let Jul:Int = 31
    let Aug:Int = 31
    let Sep:Int = 30
    let Oct:Int = 31
    let Nov:Int = 30
    
    if oneReminder == 0 {
        MonthInt = 12
        DayInt = 31
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov) > 0 {
        MonthInt = 12
        DayInt = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct) > 0{
        MonthInt = 11
        DayInt = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep) > 0{
        MonthInt = 10
        DayInt = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug) > 0{
        MonthInt = 9
        DayInt = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul) > 0{
        MonthInt = 8
        DayInt = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun) > 0{
        MonthInt = 7
        DayInt = oneReminder - (Jan+Feb+Mar+Apr+May+Jun)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May) > 0{
        MonthInt = 6
        DayInt = oneReminder - (Jan+Feb+Mar+Apr+May)
    }else if oneReminder - (Jan+Feb+Mar+Apr) > 0{
        MonthInt = 5
        DayInt = oneReminder - (Jan+Feb+Mar+Apr)
    }else if oneReminder - (Jan+Feb+Mar) > 0{
        MonthInt = 4
        DayInt = oneReminder - (Jan+Feb+Mar)
    }else if oneReminder - (Jan+Feb) > 0{
        MonthInt = 3
        DayInt = oneReminder - (Jan+Feb)
    }else if oneReminder - (Jan) > 0{
        MonthInt = 2
        DayInt = oneReminder - (Jan)
    }else if oneReminder > 0{
        MonthInt = 1
        DayInt = oneReminder
    }
    
    
    if 0 <= MonthInt, MonthInt < 10{
        month = "0\(MonthInt)"
    } else {
        month = "\(MonthInt)"
    }
    if 0 <= DayInt, DayInt < 10{
        day = "0\(DayInt)"
    } else {
        day = "\(DayInt)"
    }
    
    
    
    /*
     decimal = DateSerialvalue.truncatingRemainder(dividingBy: 1)
     decimalintoInt = Int(decimal * 24 * 60)
     
     let (HourQuotient,HourReminder) = (decimalintoInt).quotientAndRemainder(dividingBy: 60)
     let (MinitQuotient,MinitReminder) = (HourReminder).quotientAndRemainder(dividingBy: 1)
     
     if 0 <= HourQuotient, HourQuotient < 10 {
     Hour = "0\(HourQuotient)"
     } else {
     Hour = "\(HourQuotient)"
     }
     if 0 <= MinitQuotient, MinitQuotient < 10{
     Minit = "0\(MinitQuotient)"
     } else {
     Minit = "\(MinitQuotient)"
     }
     */
    
    
}


SerialtoDate()
print("\(year)/\(month)/\(day)")
//print("\(year)/\(month)/\(day),\(Hour):\(Minit)")



